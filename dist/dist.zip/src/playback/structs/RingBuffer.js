import { bufferPool } from "./BufferPool.js";
/**
 * A fast, fixed-size circular buffer for audio chunks.
 * Uses BufferPool for memory management to reduce GC pressure.
 * @public
 */
export class RingBuffer {
    buffer;
    size;
    writeOffset;
    readOffset;
    _length;
    /**
     * Gets the number of bytes currently available in the buffer.
     */
    get length() {
        return this._length;
    }
    /**
     * Creates a new RingBuffer.
     * @param size - The size of the buffer in bytes.
     */
    constructor(size) {
        this.buffer = bufferPool.acquire(size);
        this.size = size;
        this.writeOffset = 0;
        this.readOffset = 0;
        this._length = 0;
    }
    /**
     * Releases the internal buffer back to the pool.
     */
    dispose() {
        if (this.buffer) {
            bufferPool.release(this.buffer);
            this.buffer = null;
        }
    }
    /**
     * Writes a chunk of data to the buffer.
     * If the buffer is full, it overwrites the oldest data.
     * @param chunk - The data chunk to write.
     */
    write(chunk) {
        if (!this.buffer)
            return;
        const bytesToWrite = chunk.length;
        const availableAtEnd = this.size - this.writeOffset;
        if (bytesToWrite <= availableAtEnd) {
            chunk.copy(this.buffer, this.writeOffset);
        }
        else {
            chunk.copy(this.buffer, this.writeOffset, 0, availableAtEnd);
            chunk.copy(this.buffer, 0, availableAtEnd);
        }
        const newLength = this._length + bytesToWrite;
        if (newLength > this.size) {
            this.readOffset = (this.readOffset + (newLength - this.size)) % this.size;
            this._length = this.size;
        }
        else {
            this._length = newLength;
        }
        this.writeOffset = (this.writeOffset + bytesToWrite) % this.size;
    }
    /**
     * Reads up to n bytes from the buffer.
     * @param n - The maximum number of bytes to read.
     * @returns A Buffer containing the data, or null if empty or disposed.
     */
    read(n) {
        if (!this.buffer)
            return null;
        const bytesToRead = Math.min(Math.max(0, n), this._length);
        if (bytesToRead === 0)
            return null;
        const acquired = bufferPool.acquire(bytesToRead);
        const out = acquired.subarray(0, bytesToRead);
        const availableAtEnd = this.size - this.readOffset;
        if (bytesToRead <= availableAtEnd) {
            this.buffer.copy(out, 0, this.readOffset, this.readOffset + bytesToRead);
        }
        else {
            this.buffer.copy(out, 0, this.readOffset, this.size);
            this.buffer.copy(out, availableAtEnd, 0, bytesToRead - availableAtEnd);
        }
        this.readOffset = (this.readOffset + bytesToRead) % this.size;
        this._length -= bytesToRead;
        return out;
    }
    /**
     * Skips n bytes in the buffer.
     * @param n - The number of bytes to skip.
     * @returns The number of bytes actually skipped.
     */
    skip(n) {
        const bytesToSkip = Math.min(Math.max(0, n), this._length);
        this.readOffset = (this.readOffset + bytesToSkip) % this.size;
        this._length -= bytesToSkip;
        return bytesToSkip;
    }
    /**
     * Peeks up to n bytes from the buffer without advancing the read offset.
     * @param n - The maximum number of bytes to peek.
     * @returns A new Buffer containing the data, or null if empty or disposed.
     */
    peek(n) {
        if (!this.buffer)
            return null;
        const bytesToPeek = Math.min(Math.max(0, n), this._length);
        if (bytesToPeek === 0)
            return null;
        const availableAtEnd = this.size - this.readOffset;
        if (bytesToPeek <= availableAtEnd) {
            return this.buffer.subarray(this.readOffset, this.readOffset + bytesToPeek);
        }
        const acquired = bufferPool.acquire(bytesToPeek);
        const out = acquired.subarray(0, bytesToPeek);
        this.buffer.copy(out, 0, this.readOffset, this.size);
        this.buffer.copy(out, availableAtEnd, 0, bytesToPeek - availableAtEnd);
        return out;
    }
    /**
     * Gets up to n contiguous bytes from the buffer.
     * @param n - The maximum number of bytes to get.
     * @returns A Buffer subarray or a new Buffer, or null if empty or disposed.
     */
    getContiguous(n) {
        if (!this.buffer)
            return null;
        const bytesToGet = Math.min(Math.max(0, n), this._length);
        if (bytesToGet === 0)
            return null;
        const availableAtEnd = this.size - this.readOffset;
        if (bytesToGet <= availableAtEnd) {
            return this.buffer.subarray(this.readOffset, this.readOffset + bytesToGet);
        }
        const acquired = bufferPool.acquire(bytesToGet);
        const out = acquired.subarray(0, bytesToGet);
        this.buffer.copy(out, 0, this.readOffset, this.size);
        this.buffer.copy(out, availableAtEnd, 0, bytesToGet - availableAtEnd);
        return out;
    }
    /**
     * Clears the buffer.
     */
    clear() {
        this.writeOffset = 0;
        this.readOffset = 0;
        this._length = 0;
    }
}
